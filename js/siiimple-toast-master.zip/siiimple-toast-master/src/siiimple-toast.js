import siiimpleToast from './main';

window.siiimpleToast = siiimpleToast;
